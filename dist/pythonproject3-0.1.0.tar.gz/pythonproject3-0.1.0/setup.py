# setup.py
from setuptools import setup

setup(
    name="pythonproject3",
    version="0.1",
    py_modules=["app"],  # Refers to app.py in the root directory
    install_requires=[],
)
